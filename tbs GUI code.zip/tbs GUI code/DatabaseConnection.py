import sqlite3

#Creating a database class
class Database:
    def __init__(self):

    #Database connection
        self.conn = sqlite3.connect("TaxiBookingSystem.db")
        self.cur = self.conn.cursor()
        self.cur.conn.commit()
        print("Connection to database was successful")
    
    #Closes connection with database
    def __del__(self):
        self.conn.close()

    # To view all the rows present in the Customer table
    def viewCustomer(self):  
        self.cur.execute("SELECT * FROM Customer")
        rows = self.cur.fetchall()
        return rows

    # To view all the rows present in the TaxiCompanyAdmin table
    def viewAdmin(self):  
        self.cur.execute("SELECT * FROM TaxiCompanyAdmin")
        rows = self.cur.fetchall()
        return rows
    
    # To view all the rows present in the TaxiDriver table
    def viewDriver(self):  
        self.cur.execute("SELECT * FROM TaxiDriver")
        rows = self.cur.fetchall()
        return rows

    # To view all the rows present in the Booking table
    def viewBooking(self):  
        self.cur.execute("SELECT * FROM Booking")
        rows = self.cur.fetchall()
        return rows

    # inserting a new row in the Customer table.
    def insertCustomer(self, CustomerID, name, address, email, telephoneNo, paymentMethod, creditCardNo, creditCardExpiryDate, CVV): 
        self.cur.execute("INSERT INTO Customer VALUES (?,?,?,?,?,?,?,?,?)",
                         (CustomerID, name, address, email, telephoneNo, paymentMethod, creditCardNo, creditCardExpiryDate, CVV,))
        self.conn.commit()
        self.view()

    # Customer inserting a new row in the Booking table.
    def insertBooking(self, BookingID, dropOffAddress, pickUpAddress, pickUpTime, pickUpDate, paymentMethod, cancelDate, bookingDate, bookingStatus, bookingTotal, CustomerID, AdminID, DriverID): 
        self.cur.execute("INSERT INTO Customer VALUES (?,?,?,?,?,?,NULL,?,NULL,NULL,?,NULL,NULL)",
                         (BookingID, dropOffAddress, pickUpAddress, pickUpTime, pickUpDate, paymentMethod, cancelDate, bookingDate, bookingStatus, bookingTotal, CustomerID, AdminID, DriverID,))
        self.conn.commit()
        self.view()

    #Customer updating the values of the selected row in Booking table with the values passed by the user
    def updateCBooking(self, dropOffAddress, pickUpAddress, pickUpTime, pickUpDate, paymentMethod, cancelDate, bookingDate, CustomerID):
        self.cur.execute(
            "UPDATE Booking SET dropOffAddress=?, pickUpAddress=?, pickUpTime=?, pickUpDate=?, paymentMethod=?, cancelDate=?, bookingDate=? WHERE CustomerID=?", 
            (dropOffAddress, pickUpAddress, pickUpTime, pickUpDate, paymentMethod, cancelDate, bookingDate, CustomerID,))
        self.conn.commit()
        self.view()

    #Driver updating the values of the selected row in Booking table with the values passed by the user
    def updateDBooking(self, cancelDate, bookingStatus, bookingTotal, DriverID):
        self.cur.execute(
            "UPDATE Booking SET cancelDate=?, bookingStatus=?, bookingTotal=? WHERE DriverID=?", 
            (cancelDate, bookingStatus, bookingTotal, DriverID,))
        self.conn.commit()
        self.view()

    #Admin updating the values of the selected row in Booking table with the values passed by the user
    def updateABooking(self, cancelDate, bookingStatus, bookingTotal, DriverID, AdminID):
        self.cur.execute(
            "UPDATE Booking SET cancelDate=?, bookingTotal=?, DriverID=? WHERE AdminID=?", 
            (cancelDate, bookingStatus, bookingTotal, DriverID, AdminID,))
        self.conn.commit()
        self.view()

    # Customer delete the row from the booking table given the value of the id of the selected row.
    def delete(self, CustomerID):
        self.cur.execute("DELETE * FROM Booking WHERE CustomerID=?", (CustomerID,))
        self.conn.commit()
        self.view()

#------------------------Queries-------------------------#
    # to search for a Customer's booking using CustomerID
    def search(self, CustomerID=""):
        self.cur.execute(
            "SELECT * FROM Booking WHERE CustomerID=?",(CustomerID,)
        )
        list0 = self.cur.fetchall()
        self.cur.close()
        print(list0)


    # to search for a Taxi Company Admin using AdminID
    def searchAdmin(self, AdminID=""):
        self.cur.execute(
            "SELECT * FROM TaxiCompanyAdmin WHERE AdminID IS NULL"
        )
        rows = self.cur.fetchall()
        return rows

    #to search for Unassigned Bookings
    def searchBooking(self, AdminID=""):
        self.cur.execute(
            "SELECT * FROM Booking b WHERE b.AdminID is null",(AdminID,)
        )
        rows = self.cur.fetchall()
        return rows

    #to search for cancelled bookings
    def searchCancelB(self, bookingStatus="" ):
        self.cur.execute(
            "SELECT c.name, b.pickUpAdrress, b.pickUpDate, b.pickUpTime, b.paymentMethod, b.dropOffAddress, b.bookingStatus, b.bookingTotal, b.DriverID FROM Booking b, Customer c INNER JOIN Customer  On c.CustomerID = b.CustomerID WHERE b.bookingStatus = ?",
            (bookingStatus,)
        )
        rows = self.cur.fetchall()
        return rows


#db = Database()

