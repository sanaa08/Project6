from sqlite3.dbapi2 import Error
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import sqlite3

#Make a Booking Screen with tkinter
def MBooking():
    MBscreen = tk.Tk()
    MBscreen.geometry("500x500")
    MBscreen.title("Taxi Booking System")
    MBscreen.configure(bg="aliceblue")
    MBheading = tk.Label(MBscreen,text="Make a Booking", bg="silver", fg="grey", width="500", height="2")
    MBheading.pack()

    #Heading for make a booking form
    heading1 = tk.Label(MBscreen, text="Please complete the below form", bg="silver", fg="grey",width="500", height="4" )
    heading1.pack()
    
    #Labels in make a booking form
    BookingID = tk.Label(MBscreen, text ="BookingID", bg="silver", fg="grey", width="30", height="1").place(x=100, y=80,)
    dropOffAddres = tk.Label(MBscreen, text ="Pick Up Address", bg="silver", fg="grey", width="30", height="1").place(x=100, y=100,)
    pickUpAddress = tk.Label(MBscreen, text ="Drop off Address", bg="silver", fg="grey", width="30", height="1").place(x=100, y=120,)
    pickUpTime = tk.Label(MBscreen, text ="Pick Up Time", bg="silver", fg="grey", width="30", height="1").place(x=100, y=140,)
    pickUpDate = tk.Label(MBscreen, text ="Pick Up Date", bg="silver", fg="grey", width="30", height="1").place(x=100, y=160,)
    paymentMethod  = tk.Label(MBscreen, text ="Payment Method", bg="silver", fg="grey", width="30", height="1").place(x=100, y=180,)
    bookingDate = tk.Label(MBscreen, text ="Booking Date", bg="silver", fg="grey", width="30", height="1").place(x=100, y=200, )

    #Entry in make a booking form
    BookingIDEntry = tk.Entry(MBscreen, bg="white", fg="black")
    BookingIDEntry.place(x=300, y=80)

    dropOffAddressEntry = tk.Entry(MBscreen,  bg="white", fg="black")
    dropOffAddressEntry.place(x=300, y=100)

    pickUpAddressEntry = tk.Entry(MBscreen, bg="white", fg="black")
    pickUpAddressEntry.place(x=300, y=120)

    pickUpTimeEntry = tk.Entry(MBscreen, bg="white", fg="black")
    pickUpTimeEntry.place(x=300, y=140)

    pickUpDateEntry = tk.Entry(MBscreen, bg="white", fg="black")
    pickUpDateEntry.place(x=300, y=160)

    paymentMethodEntry = tk.Entry(MBscreen, bg="white", fg="black")
    paymentMethodEntry.place(x=300, y=180)

    bookingDateEntry = tk.Entry(MBscreen, bg="white", fg="black")
    bookingDateEntry.place(x=300, y=200)

    #A function created for the Submit button
    def submitCommand():
        #Variables created for the data entered by the user
        BookingID = BookingIDEntry.get()
        dropOffAddress = dropOffAddressEntry.get()
        pickUpAddress = pickUpAddressEntry.get()
        pickUpTime = pickUpTimeEntry.get()
        pickUpDate = pickUpDateEntry.get()
        paymentMethod = paymentMethodEntry.get()
        bookingDate = bookingDateEntry.get()

        #If-Elif-Else statement to verify that the Make a Booking form is filled out correctly
        if BookingID == "":
            messagebox.showinfo("ERROR", "Please fill in all information")
        elif dropOffAddress == "":
            messagebox.showinfo("ERROR","Please fill in all information")
        elif pickUpAddress == "":
            messagebox.showinfo("ERROR","Please fill in all information")
        elif pickUpTime == "":
            messagebox.showinfo("ERROR","Please fill in all information")
        elif pickUpDate == "":
            messagebox.showinfo("ERROR","Please fill in all information")    
        elif paymentMethod == "":
             messagebox.showinfo("ERROR","Please fill in all information")
        elif bookingDate == "":
             messagebox.showinfo("ERROR","Please fill in all information")
        else:
            messagebox.showinfo("Booked","Your booking is created successfully. Thank you!")
        
        #Function to add new bookings into the system
        def insertBooking(self,BookingID, dropOffAddress, pickUpAddress, pickUpTime, pickUpDate, paymentMethod, bookingDate): 
            self.conn = sqlite3.connect("TaxiBookingSystem.db")
            cur = self.conn.cursor()
            cur.execute(
            "INSERT INTO Booking (BookingID, dropOffAddress, pickUpAdrress, pickUpTime, pickUpDate, paymentMethod, bookingDate,CustomerID)VALUES(?,?,?,?,?,?,?,?);",
            (BookingID, dropOffAddress, pickUpAddress, pickUpTime, pickUpDate, paymentMethod, bookingDate))
            self.conn.commit()
            self.conn.cursor.close()
            self.conn.close()
        insertBooking()

    #Function to clear all the data on the Make a booking form
    def clearCommand():
        BookingIDEntry.delete(0,END)
        dropOffAddressEntry.delete(0,END)
        pickUpAddressEntry.delete(0,END)
        pickUpTimeEntry.delete(0,END)
        pickUpDateEntry.delete(0,END)
        paymentMethodEntry.delete(0,END)
        bookingDateEntry.delete(0,END)

    #Created the Submit button
    SubmitB = Button(MBscreen, text="Submit", command=submitCommand)
    SubmitB.pack(side=tk.RIGHT, padx=10, ipadx=10)

    # Create the Clear button 
    ClearB = tk.Button(MBscreen, text="Cancel",command=clearCommand )
    ClearB.pack(side=tk.RIGHT, ipadx=10)

#View a Booking Screen
def VBooking():
    VBscreen = tk.Tk()
    VBscreen.geometry("1050x500")
    VBscreen.title("Taxi Booking System")
    VBscreen.configure(bg="aliceblue")
    VBheading = tk.Label(VBscreen, text="View your Bookings", bg="silver", fg="grey", width="500", height="1")
    VBheading.pack()

    VBheading1 = tk.Label(VBscreen,text="Please enter your CustomerID", bg="silver", fg="grey", width="500", height="1")
    VBheading1.pack()

    #Labels in View Booking form
    CustomerLabel = tk.Label(VBscreen, text="CustomerID", bg="silver", fg="grey", width="30", height="1")
    CustomerLabel.place(x=60, y=175)
    
    #Entry in form
    EC = tk.Entry(VBscreen, bg="white", fg="black")
    EC.place(x=100, y=200)

    #Labels 
    L1 = tk.Label(VBscreen, text="BookingID", bg="silver", fg="grey")
    L1.place(x=400, y=175)
    
    #Entry 
    E1 = tk.Entry(VBscreen)
    #E1.place(x500, y=300)

    #Create a frame
    frame = tk.Frame(VBscreen, width=100, height="5")
    frame.pack()

    #Create Headings
    cTree = ttk.Treeview(frame, columns=(1,2,3,4,5,6,7,8,9,10,11,12,13), show="headings", height="5")
    cTree.pack()

    cTree.heading(1,text="BookingID")
    cTree.heading(2,text="Drop Off Address")
    cTree.heading(3,text="Pick Up Address")
    cTree.heading(4,text="Pick Up Time")
    cTree.heading(5,text="Pick Up Date")
    cTree.heading(6,text="Payment Method")
    cTree.heading(7,text="Cancel Date")
    cTree.heading(8,text="Booking Date")
    cTree.heading(9,text="Booking Status")
    cTree.heading(10,text="Cost")
    cTree.heading(11,text="CustomerID")
    cTree.heading(12,text="AdminID")
    cTree.heading(13,text="DriverID")

    #Function search created to search for that specific customer's booking
    def search():
        #Variable created to store the CustomerID entered by the user
        CustomerID = EC.get()
        #Database connection
        conn = sqlite3.connect("TaxiBookingSystem.db")
        cur = conn.cursor()
        #If-Elif-Else statement to search for the customer's booking based on the CustomerID
        if CustomerID == "C01":
            cur.execute("SELECT * FROM Booking b WHERE b.CustomerID='C01'")
            rows = cur.fetchall()
    
            for i in rows:
                cTree.insert('', 'end', values=i)

        elif CustomerID == "C02":
            cur.execute("SELECT * FROM Booking b WHERE b.CustomerID='C02'")
            rows = cur.fetchall()
    
            for i in rows:
                cTree.insert('', 'end', values=i)
    #Search button created
    Search = Button(VBscreen, text="Search", command=search)
    Search.place(x=300, y=200)

    #Function cancel created to cancel a Customer's booking
    def cancel(cancelDate="", bookingStatus="", BookingID=""):
        #Variables to store the data entered by the Customer
        BookingID = E1.get()
        #bookingStatus = E2.get()
        #cancelDate = E3.get()        
        #Database Connection
        conn = sqlite3.connect("TaxiBookingSystem.db")
        cur = conn.cursor()
        #SQL Query to update the data in the Database
        cur.execute("UPDATE Booking SET cancelDate=?, bookingStatus=? WHERE BookingID=?;", (cancelDate, bookingStatus, BookingID))
        rows = cur.fetchall()
    
        for i in rows:
            cTree.insert('', 'end', values=i)

        messagebox.showinfo( "Cancelled", "Booking has been cancelled")

    #Cancel button created
    CancelB = Button(VBscreen, text="Cancel Booking", command=cancel)
    CancelB.place(x=500, y=200) 

#CustomerGUI main screen created by using tkinter
def CustomerGUI():
    Cscreen = tk.Tk()
    Cscreen.geometry("500x300")
    Cscreen.title("Taxi Booking System")
    Cscreen.configure(bg="aliceblue")
    Cheading = tk.Label(text="Taxi Booking System", bg="silver", fg="grey", width="500", height="2")
    Cheading.pack()

    Clabel = tk.Label(text="Welcome to the Taxi Booking System.",
                     bg="silver", fg="grey", width="800", height="3")
    Clabel.pack()

    #Buttons created
    Mbutton = tk.Button(text="Make a Booking", height="2", width="30", command = MBooking)
    Mbutton.pack()

    Vbutton = tk.Button(text="View a Booking", height="2", width="30", command = VBooking)
    Vbutton.pack()
    
    Vbutton = tk.Button(text="Cancel a Booking", height="2", width="30", command = VBooking)
    Vbutton.pack()

    Cscreen.mainloop()

CustomerGUI()
