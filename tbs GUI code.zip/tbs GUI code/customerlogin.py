from tkinter import *
import tkinter as tk
from tkinter import messagebox
import sqlite3

#Register screen created using tkinter
def register():
    registerScreen = tk.Tk()
    registerScreen.geometry("500x500")
    registerScreen.title("Registration Form")
    registerScreen.configure(bg="aliceblue")

    #Heading for registration form
    heading1 = tk.Label(registerScreen,text="Please complete all the required informations.", bg="silver", fg="grey", width="500", height="3")
    heading1.pack()
    
    #Labels in the registration form
    CustomerID = tk.Label(registerScreen, text="CustomerID",bg="silver", fg="grey", width="40", height="1" )
    CustomerID.place(x=100, y=60)
    
    name = tk.Label(registerScreen, text ="Name", bg="silver", fg="grey", width="40", height="1")
    name.place(x=100, y=80)

    password = tk.Label(registerScreen, text= "Password",bg="silver", fg="grey", width="40", height="1" )
    password.place(x=100, y=100)

    address = tk.Label(registerScreen, text = "Address", bg="silver", fg="grey", width= "40", height="1")
    address.place(x=100, y=120)

    email = tk.Label(registerScreen, text = "Email", bg="silver", fg="grey", width="40", height="1")
    email.place(x=100, y=140)

    telephoneNo = tk.Label(registerScreen, text = "telephone number", bg="silver", fg="grey", width="40", height="1")
    telephoneNo.place(x=100, y=160)
    
    paymentMethod = tk.Label(registerScreen, text = "payment methond", bg="silver", fg="grey", width="40", height="1")
    paymentMethod.place(x=100, y=180)
    
    creditCardNo = tk.Label(registerScreen, text = "Credit Card number", bg="silver", fg="grey", width="30", height="1")
    creditCardNo.place(x=100, y=200)

    creditCardExpiryDate = tk.Label(registerScreen, text = "Credit Card expiry date", bg="silver", fg="grey", width="30", height="1")
    creditCardExpiryDate.place(x=100, y=220)
    
    CVV = tk.Label(registerScreen, text = "CVV", bg="silver", fg="grey", width="30", height="1")
    CVV.place(x=100, y=240)
    
 

   #Entry in registration form
    CustomerIDEntry =tk.Entry(registerScreen, bg="white", fg="black" )
    CustomerIDEntry.place(x=350, y=60)
    
    nameEntry = tk.Entry(registerScreen, bg="white", fg="black")
    nameEntry.place(x=350,y=80)

    passwordEntry = tk.Entry(registerScreen, bg="white", fg="black")
    passwordEntry.place(x=350, y=100)

    addressEntry = tk.Entry(registerScreen, bg="white", fg="black")
    addressEntry.place(x=350,y=120)

    emailEntry = tk.Entry(registerScreen, bg="white", fg="black")
    emailEntry.place(x=350,y=140)
    
    telephoneNoEntry = tk.Entry(registerScreen, bg="white", fg="black")
    telephoneNoEntry.place(x=350,y=160)
    
    paymentMethodEntry = tk.Entry(registerScreen, bg="white", fg="black")
    paymentMethodEntry.place(x=350,y=180)

    creditCardNoEntry = tk.Entry(registerScreen, bg="white", fg="black")
    creditCardNoEntry.place(x=350,y=200)
    
    creditCardExpiryDateEntry = tk.Entry(registerScreen, bg="white", fg="black")
    creditCardExpiryDateEntry.place(x=350,y=220)

    CVVEntry = tk.Entry(registerScreen, bg="white", fg="black")
    CVVEntry.place(x=350,y=240)

    #A function called validateRegister is created for the Register button
    def validateRegister():
        #Variables created to store the data entered by the user
        name = nameEntry.get()
        address = addressEntry.get()
        email = emailEntry.get()
        telephoneNo = telephoneNoEntry.get()
        paymentMethod = paymentMethodEntry.get()
        password = passwordEntry.get()
        CustomerID = CustomerIDEntry.get()
        creditCardNo = creditCardNoEntry.get()
        creditCardExpiryDate = creditCardNoEntry.get()
        CVV = CVVEntry.get()
        #If-Else statement created to verify that the regisrtation form is filled out properly
        if name == "":
            messagebox.showinfo("ERROR", "Please fill in all information")
        elif address == "":
            messagebox.showinfo("ERROR","Please fill in all information")
        elif email == "":
            messagebox.showinfo("ERROR","Please fill in all information")
        elif telephoneNo == "":
            messagebox.showinfo("ERROR","Please fill in all information")
        elif paymentMethod == "":
             messagebox.showinfo("ERROR","Please fill in all information")
        elif password == "":
             messagebox.showinfo("ERROR","Please fill in all information")
        elif CustomerID == "":
             messagebox.showinfo("ERROR","Please fill in all information")
        else:
            messagebox.showinfo("Registered","You have been registered, please continue to the login")

        #Function to save a new Customer information on the system
        def insertCustomer(self, CustomerID, name, password, address, email, telephoneNo, paymentMethod,creditCardNo, creditCardExpiryDate, CVV): 
            #Database Connection
            self.conn = sqlite3.connect("TaxiBookingSystem.db")
            self.cur = self.conn.cursor()
            #SQL Query
            self.cur.execute("INSERT INTO Customer (CustomerID, name, password, address, email, telephoneNo, paymentMethod, creditCardNo, creditCardExpiryDate, CVV) VALUES (?,?,?,?,?,?,?,?,?,?);",
                         (CustomerID, name, password, address, email, telephoneNo, paymentMethod,))
            self.conn.commit()
        insertCustomer()

    #Register button is created
    registerB = Button(registerScreen, text="Register", command=validateRegister)
    registerB.place(x=100, y=280)

#Login screen
import tkinter.messagebox as MessageBox
def login():
    loginScreen = tk.Tk()
    loginScreen.geometry("400x200")
    loginScreen.title("Login")
    loginScreen.configure(bg="aliceblue")

    #Title for Login
    title = tk.Label(loginScreen, text="Please complete the below form", bg="silver", fg="grey", width="40", height="1")
    title.place(x=50,y=50)

    #Lables for Login created
    userID = tk.Label(loginScreen, text="UserID", bg="silver", fg="grey", width="20", height="1")
    userID.place(x=100, y=80)

    password = tk.Label(loginScreen, text="Password", bg="silver", fg="grey", width="20", height="1")
    password.place(x=100, y=110)

    #Entry for Login created
    userIDEntry = tk.Entry(loginScreen, bg="white", fg="black")
    userIDEntry.place(x=300,y=80)

    passwordEntry = tk.Entry(loginScreen, bg="white", fg="black")
    passwordEntry.place(x=300, y=110)

    #A function name validate is created for the Login button
    def validate():
        #Variables to store the data entered by the user
        userID = userIDEntry.get()
        password = passwordEntry.get()

        #If-Elif-Else statement to verify that the Login is done correctly and the login is valid 
        if userID =="":
            messagebox.showinfo( "ERROR!", "Please enter your userID")
        elif password == "":
            messagebox.showinfo( "ERROR!", "Please enter your password")
        elif userID == "C01" and password == "123":
            messagebox.showinfo( "Login", "Login was valid")    
        elif userID == "C02" and password == "111":
            messagebox.showinfo( "Login", "Login was valid!")
        elif userID == "C03" and password == "222":
            messagebox.showinfo( "Login", "Login was valid!")
        else:
            messagebox.showinfo( "ERROR", "Login was invalid!")

    #Button Login is created
    login = Button(loginScreen, text="Login", command=validate)
    login.place(x=200, y=140)


    #Function created to search for the Customer's ID and password
    def search(CustomerID=""):
            conn = sqlite3.connect("TaxiBookingSystem.db")
            cur = conn.cursor()
            cur.execute("SELECT CustomerID, password FROM Customer WHERE CustomerID=?",(CustomerID,))
            list = cur.fetchall()
            cur.close()
            list
    search()
#main screen the user would see when opeining the Taxi Booking System
def mainScreen():
    global screen
    screen = tk.Tk()
    screen.geometry("800x200")
    screen.title("Taxi Booking System")
    screen.configure(bg="aliceblue")
    heading = tk.Label(text="Taxi Booking System", bg="silver", fg="grey", width="800", height="4")
    heading.pack()
    
    label = tk.Label(text="Welcome to the Taxi Booking System. ",
                     bg="white", fg="black", width="800", height="3")
    label.pack()

    #Login and Register Buttons created
    button = tk.Button(text="Login", height="2", width="40", command = login)
    button.pack()

    button = tk.Button(text="Register", height="2", width="40", command = register)
    button.pack()

    screen.mainloop()

mainScreen()
